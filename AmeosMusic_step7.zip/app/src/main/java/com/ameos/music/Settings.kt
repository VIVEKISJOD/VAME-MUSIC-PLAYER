package com.ameos.music

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: MainViewModel) {
    BackHandler { vm.showSettings = false }
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF3A1511), Color(0xFF0E0B0B), Color(0xFF0A0808)),
                    endY = 1500f
                )
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.showSettings = false }) {
                    Icon(Icons.Filled.ArrowBack, null, tint = Color.White)
                }
                Text(
                    "Settings", fontSize = 34.sp, fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }

            SectionLabel("Home title")
            TextField(
                value = vm.title,
                onValueChange = { vm.updateTitle(it) },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0x33FFFFFF),
                    unfocusedContainerColor = Color(0x33FFFFFF),
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Whatever you type replaces the big word at the top of Home.",
                fontSize = 12.sp, color = Color(0xFF8C7C7E),
                modifier = Modifier.padding(top = 6.dp)
            )

            SectionLabel("Your taste")
            Row(
                Modifier.fillMaxWidth().clickable { vm.showOnboarding = true },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Change music taste", fontSize = 16.sp, color = Color.White)
                    Text(
                        if (vm.genres.isEmpty()) "Pick the types of songs you like."
                        else vm.genres.joinToString(", "),
                        fontSize = 12.sp, color = Color(0xFF8C7C7E)
                    )
                }
            }

            SectionLabel("Playback")
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Endless queue", fontSize = 16.sp, color = Color.White)
                    Text(
                        "When the queue ends, keep adding similar songs.",
                        fontSize = 12.sp, color = Color(0xFF8C7C7E)
                    )
                }
                Switch(checked = vm.endless, onCheckedChange = { vm.setEndlessOn(it) })
            }

            SectionLabel("About")
            Text(
                "VAME Music. Interface design based on AmeOS 16 by the AmeOS team, " +
                    "licensed CC BY 4.0.",
                fontSize = 13.sp, color = Color(0xFFD9C0C2)
            )
            Spacer(Modifier.height(40.dp))
        }
    }
}
