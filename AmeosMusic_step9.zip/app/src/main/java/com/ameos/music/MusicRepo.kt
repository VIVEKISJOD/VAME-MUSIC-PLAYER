package com.ameos.music

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

data class Song(
    val title: String,
    val artist: String,
    val url: String,
    val cover: String?,
    val durationSec: Long
)

data class Resolved(val audio: String, val related: List<Song>)

object MusicRepo {

    // "Official songs only": hides remixes, slowed/reverb, lofi, covers, karaoke, mashups
    // and fan/lyrics channels. Set from Settings (MainViewModel keeps it in sync).
    @Volatile
    var officialOnly: Boolean = true

    // words that are junk anywhere in the title
    private val strongJunk = Regex(
        "\\b(remix|remixed|slowed|reverb|sped up|speed up|speedup|nightcore|mashup|karaoke|" +
            "lofi|lo-fi|8d|bass boosted|bass boost|bootleg|unofficial|tiktok|ringtone|" +
            "whatsapp status|jhankar|tapori)\\b",
        RegexOption.IGNORE_CASE
    )

    // words that are junk only in the (brackets) / - dash / | pipe part of the title
    private val weakJunk = Regex(
        "\\b(cover|dj|mix|instrumental|flip|edit by|version by)\\b",
        RegexOption.IGNORE_CASE
    )

    // channels that are not the artist or the label
    private val junkChannel = Regex(
        "\\b(lyrics|lyrical|lofi|lo-fi|remix|remixes|slowed|reverb|nightcore|8d|karaoke|" +
            "mashup|cover|covers|fan made|unofficial|status|ringtones)\\b",
        RegexOption.IGNORE_CASE
    )

    private fun isOfficial(s: Song): Boolean {
        val t = s.title
        if (strongJunk.containsMatchIn(t)) return false
        val cut = t.indexOfFirst { it == '(' || it == '[' || it == '-' || it == '|' }
        if (cut >= 0 && weakJunk.containsMatchIn(t.substring(cut))) return false
        if (junkChannel.containsMatchIn(s.artist)) return false
        return true
    }

    // if the person typed remix/slowed/lofi themselves, they want those, so do not filter
    private fun applyFilter(list: List<Song>, query: String?): List<Song> {
        if (!officialOnly) return list
        if (query != null && strongJunk.containsMatchIn(query)) return list
        val clean = list.filter { isOfficial(it) }
        return if (clean.isEmpty()) list else clean
    }

    suspend fun search(query: String): List<Song> = withContext(Dispatchers.IO) {
        val extractor = ServiceList.YouTube.getSearchExtractor(
            query,
            listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS),
            ""
        )
        extractor.fetchPage()
        val all = extractor.initialPage.items
            .filterIsInstance<StreamInfoItem>()
            .map { toSong(it) }
        applyFilter(all, query)
    }

    suspend fun resolve(videoUrl: String): Resolved = withContext(Dispatchers.IO) {
        val info = StreamInfo.getInfo(videoUrl)
        val streams = info.audioStreams
        val progressive = streams.filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
        val pool = if (progressive.isNotEmpty()) progressive else streams
        val best = pool.maxByOrNull { it.averageBitrate }
            ?: throw IllegalStateException("Is song ki audio nahi mili")
        val related = try {
            val all = info.relatedItems
                .filterIsInstance<StreamInfoItem>()
                .filter { it.duration in 60L..600L }
                .map { toSong(it) }
            if (officialOnly) all.filter { isOfficial(it) } else all
        } catch (e: Exception) {
            emptyList()
        }
        Resolved(best.content, related)
    }

    private fun toSong(item: StreamInfoItem): Song = Song(
        title = item.name ?: "Unknown",
        artist = item.uploaderName ?: "",
        url = item.url,
        cover = bigCover(item.thumbnails.maxByOrNull { it.height }?.url),
        durationSec = item.duration
    )

    private fun bigCover(url: String?): String? {
        if (url == null) return null
        return if (url.contains("googleusercontent.com") || url.contains("ggpht.com")) {
            url.replace(Regex("=w\\d+-h\\d+.*$"), "=w600-h600-l90-rj")
        } else {
            url
        }
    }
}
