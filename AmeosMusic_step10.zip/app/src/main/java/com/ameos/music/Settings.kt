package com.ameos.music

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: MainViewModel) {
    BackHandler { vm.showSettings = false }
    LaunchedEffect(Unit) { vm.refreshCacheSize() }
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF3A1511), Color(0xFF0E0B0B), Color(0xFF0A0808)),
                    endY = 1500f
                )
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.showSettings = false }) {
                    Icon(Icons.Filled.ArrowBack, null, tint = Color.White)
                }
                Text(
                    "Settings", fontSize = 34.sp, fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }

            SectionLabel("Home title")
            TextField(
                value = vm.title,
                onValueChange = { vm.updateTitle(it) },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0x33FFFFFF),
                    unfocusedContainerColor = Color(0x33FFFFFF),
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Whatever you type replaces the big word at the top of Home.",
                fontSize = 12.sp, color = Color(0xFF8C7C7E),
                modifier = Modifier.padding(top = 6.dp)
            )

            SectionLabel("Your taste")
            Row(
                Modifier.fillMaxWidth().clickable { vm.showOnboarding = true },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Change music taste", fontSize = 16.sp, color = Color.White)
                    Text(
                        if (vm.genres.isEmpty()) "Pick the types of songs you like."
                        else vm.genres.joinToString(", "),
                        fontSize = 12.sp, color = Color(0xFF8C7C7E)
                    )
                }
            }

            SectionLabel("Playback")
            SwitchRow(
                "Endless queue", "When the queue ends, keep adding similar songs.",
                vm.endless
            ) { vm.setEndlessOn(it) }
            SwitchRow(
                "Stop when removed from recents", "Swipe the app away and the music stops completely.",
                vm.stopOnSwipe
            ) { vm.setStopOnSwipe(it) }
            Text(
                "Audio quality", fontSize = 16.sp, color = Color.White,
                modifier = Modifier.padding(top = 10.dp)
            )
            Text(
                "Lower quality uses less data. Applies from the next song.",
                fontSize = 12.sp, color = Color(0xFF8C7C7E)
            )
            QualityChips(vm)

            SectionLabel("Songs")
            SwitchRow(
                "Official songs only",
                "Hides remixes, slowed + reverb, lofi, covers and lyrics-channel uploads.",
                vm.officialOnly
            ) { vm.setOfficialOnlyOn(it) }
            SwitchRow(
                "Hinglish lyrics", "Shows Hindi lyrics written in English letters.",
                vm.hinglish
            ) { vm.setHinglishOn(it) }

            SectionLabel("Storage")
            ActionRow(
                "Clear cache",
                if (vm.cacheSize.isEmpty()) "Cached covers and song links"
                else vm.cacheSize + " used by covers and song links"
            ) { vm.clearCache() }
            ActionRow(
                "Clear listening history", "Resets Last played and Your Type suggestions."
            ) { vm.clearHistory() }

            SectionLabel("About")
            Text(
                "VAME Music v0.5.0. Interface design based on AmeOS 16 by the AmeOS team, " +
                    "licensed CC BY 4.0.",
                fontSize = 13.sp, color = Color(0xFFD9C0C2)
            )
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, color = Color.White)
            Text(sub, fontSize = 12.sp, color = Color(0xFF8C7C7E))
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ActionRow(title: String, sub: String, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp)
    ) {
        Text(title, fontSize = 16.sp, color = Color.White)
        Text(sub, fontSize = 12.sp, color = Color(0xFF8C7C7E))
    }
}

@Composable
private fun QualityChips(vm: MainViewModel) {
    val names = listOf("High", "Normal", "Data saver")
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        names.forEachIndexed { i, n ->
            val on = vm.quality == i
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (on) Color(0xFFFFB3B9) else Color(0x33FFFFFF))
                    .clickable { vm.setQuality(i) }
                    .padding(horizontal = 16.dp, vertical = 9.dp)
            ) {
                Text(
                    n, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    color = if (on) Color(0xFF3A1511) else Color.White
                )
            }
        }
    }
}
