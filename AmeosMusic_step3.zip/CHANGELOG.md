# VAME Music changelog

## Step 3 (v0.3) - NOT yet uploaded by user as of 22 Oct 2026 00:50 (includes Step 2 too)
Fixed
- Music now shows in the notification, lock screen and Xiaomi HyperOS island (session was never added to the service). Notification Next/Prev buttons work with the app queue.
- Home chips (All / Music / Podcasts / Playlists) now work.
- Top-right user icon now opens Settings.
Added
- Now Playing screen (pill opens it) + synced Lyrics view + "..." menu (Open in Music app, Karaoke mode, Shuffle).
- Loop button: off / all / one.
- Sleep timer: 15/30/45/60 min or end of song (in "..." menu).
- Endless queue: when the queue is nearly done, similar songs are added automatically. Toggle in "..." menu and Settings.
- "Up next" queue panel (queue icon in Now Playing), tap a song to jump.
- "Suggested for you" on Home, based on the song you played.
- Settings page: type your own Home title (replaces "Music"), endless toggle, About with AmeOS credit.
- Likes are now saved on the phone (survive closing the app). Title and endless setting saved too.
- Animations: tab fade, Now Playing slides up, Settings slides in, queue panel slides up, covers fade in, chip colour animates.
- Faster playback: song shows instantly, next song's link is prepared in advance.
Added after user feedback (00:55)
- Dedicated lyrics button in Now Playing (also tap the cover). New full-screen Lyrics screen like the user's reference: dark background, current line big and white, other lines blurred (blur only on Android 12+), current line fills in word by word, tap a line to jump, top pill with song, bottom back / big play-pause / more buttons.
- Picking a new song: pill and screens switch to the new song instantly, old song pauses at once, loading circle shows until the new one starts.
- Sleep timer has a Custom minutes box.
- "Let the song finish" switch: when the timer ends, the current song plays to its end instead of cutting off mid-song (on by default).
- "Play this song N times, then stop": 1, 2, 3, 5 or custom times (e.g. Hanuman Chalisa 3 times). Song restarts from the start, plays N times fully, then stops.
- Menu item renamed "Sleep and repeat".

Not yet (next steps): Figma-exact Home/Library redesign + glass look, album/artist/playlist pages, playlist creation with custom cover, onboarding page, offline downloads, Hinglish lyrics.
