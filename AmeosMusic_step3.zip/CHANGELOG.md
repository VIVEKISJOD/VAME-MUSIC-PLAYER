# VAME Music changelog

## Step 3 (v0.3) - NOT yet uploaded by user as of 22 Oct 2026 00:50 (includes Step 2 too)
Fixed
- Music now shows in the notification, lock screen and Xiaomi HyperOS island (session was never added to the service). Notification Next/Prev buttons work with the app queue.
- Home chips (All / Music / Podcasts / Playlists) now work.
- Top-right user icon now opens Settings.
Added
- Now Playing screen (pill opens it) + synced Lyrics view + "..." menu (Open in Music app, Karaoke mode, Shuffle).
- Loop button: off / all / one.
- Sleep timer: 15/30/45/60 min or end of song (in "..." menu).
- Endless queue: when the queue is nearly done, similar songs are added automatically. Toggle in "..." menu and Settings.
- "Up next" queue panel (queue icon in Now Playing), tap a song to jump.
- "Suggested for you" on Home, based on the song you played.
- Settings page: type your own Home title (replaces "Music"), endless toggle, About with AmeOS credit.
- Likes are now saved on the phone (survive closing the app). Title and endless setting saved too.
- Animations: tab fade, Now Playing slides up, Settings slides in, queue panel slides up, covers fade in, chip colour animates.
- Faster playback: song shows instantly, next song's link is prepared in advance.
Not yet (next steps): Figma-exact Home/Library redesign + glass look, album/artist/playlist pages, playlist creation with custom cover, onboarding page, offline downloads, Hinglish lyrics.
