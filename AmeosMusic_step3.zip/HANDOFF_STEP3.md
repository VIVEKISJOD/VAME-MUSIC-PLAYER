# AMEOS MUSIC HANDOFF - STEP 3 (v0.3) + FULL ROADMAP (22 Oct 2026, 00:50)
Read with HANDOFF_STEP1.md, HANDOFF_UPDATE_21Oct.md, CHANGELOG.md. Rules: do not greet like new, ONE question per message, short replies, never ask user to edit code, full zips (new name each time AmeosMusic_stepN.zip, build.yml takes the highest N), a handoff with every file, ALWAYS give the user a short list of what was fixed/added with every change. Claude cannot compile (no network to Google/Maven); user builds on GitHub Actions and pastes errors. Check brace balance before sending.

## State
- User confirmed Step 1.1 plays songs. User has NOT yet uploaded step2 or step3; he said he will upload step3 after more is added. step3 zip = Step 2 + notification fix + loop/sleep/endless/queue/settings/animations (see CHANGELOG.md). If the build fails, user pastes errors; likely risky spots: NewPipe `info.relatedItems` name, ForwardingPlayer overrides in PlaybackService.kt, deprecated icons.

## Added at 00:55 (see CHANGELOG.md)
LyricsScreen.kt (new lyrics UI), SleepDialog.kt (custom timer, let-song-finish, play N times), PlayerMenuButton shared, instant song switch. v0.3.1. Still not uploaded/compiled by user.

## User's feature list (never forget)
- No account ever. First-launch onboarding "what type of songs do you like?" feeding Home/Search/Your Type.
- Settings page (must) - started (title rename, endless). More: audio quality, download quality, clear cache, Hinglish toggle.
- Playlists: user can CREATE playlists with CUSTOM COVER (photo picker), real and persistent. Library playlists are currently fake (Daily/Bangers/Evening just search).
- Your Type: currently only a generic search "new music this week"; rebuild from onboarding taste + history. User asked if it works.
- OFFLINE: download songs, play offline, Downloads screen.
- Lyrics in HINGLISH for Hindi songs: android.icu Transliterator "Devanagari-Latin; Latin-ASCII", toggle in Settings.
- SMOOTHEST animations everywhere (shared cover transition mini player -> Now Playing, press scale, springs).
- LIQUID / SOFT GLASS look (translucent layers, light edge, blur on Android 12+). Asked user Android version, no answer yet.
- UI must match AmeOS 16 Figma screenshots exactly (7 screenshots: Home, Search, Your Type, Library, album page, artist/song page, Daily playlist page, Now Playing, Lyrics, "..." menu). Credit AmeOS team CC BY 4.0 (done in Settings About).

## Order
- Step 4: Home/Search/Your Type/Library redone to Figma + glass look + more animations + album/artist/playlist pages.
- Step 5: playlist creation with custom cover + persistence of playlists/last played + onboarding page.
- Step 6: offline downloads + offline playback.
- Step 7: Hinglish lyrics toggle, Animate cover, full Settings, final polish.
