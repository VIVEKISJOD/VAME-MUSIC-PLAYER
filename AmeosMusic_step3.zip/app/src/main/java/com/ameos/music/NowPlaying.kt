package com.ameos.music

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Subject
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Pink = Color(0xFFFFB3B9)

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return (s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0')
}

// "..." button with its menu. Used on Now Playing and on the Lyrics screen.
@Composable
fun PlayerMenuButton(vm: MainViewModel, size: Dp = 40.dp) {
    val song = vm.current ?: return
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    Box {
        Box(
            Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color(0x33FFFFFF))
                .clickable { open = true },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.MoreHoriz, null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("Open in Music app") },
                leadingIcon = { Icon(Icons.Filled.MusicNote, null) },
                onClick = {
                    open = false
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(song.url)))
                    } catch (e: Exception) {
                    }
                }
            )
            DropdownMenuItem(
                text = { Text("Shuffle") },
                leadingIcon = { Icon(Icons.Filled.Shuffle, null) },
                onClick = { open = false; vm.shuffleQueue() }
            )
            DropdownMenuItem(
                text = {
                    Text(
                        if (vm.sleepLeftSec > 0)
                            "Sleep and repeat (" + fmt(vm.sleepLeftSec * 1000L) + ")"
                        else if (vm.timesLeft > 0) "Sleep and repeat (" + vm.timesLeft + " plays left)"
                        else if (vm.sleepAfterSong) "Sleep and repeat (end of song)"
                        else "Sleep and repeat"
                    )
                },
                leadingIcon = { Icon(Icons.Filled.Timer, null) },
                onClick = { open = false; vm.showSleepDialog = true }
            )
            DropdownMenuItem(
                text = { Text(if (vm.endless) "Endless: On" else "Endless: Off") },
                leadingIcon = { Icon(Icons.Filled.Autorenew, null) },
                onClick = { open = false; vm.setEndlessOn(!vm.endless) }
            )
        }
    }
}

@Composable
fun NowPlayingScreen(vm: MainViewModel) {
    val song = vm.current ?: return
    var showQueue by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    BackHandler { vm.showPlayer = false }
    BackHandler(enabled = showQueue) { showQueue = false }

    LaunchedEffect(song.url) {
        while (true) {
            pos = vm.player.currentPosition
            val d = vm.player.duration
            dur = if (d > 0) d else song.durationSec * 1000
            delay(300)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF7A1F22), Color(0xFF4A1014), Color(0xFF2A0A0D))
                )
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { }
    ) {
        Cover(
            song.cover,
            Modifier.fillMaxSize().alpha(0.30f).blur(50.dp),
            RoundedCornerShape(0.dp)
        )
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            // header
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.showPlayer = false }) {
                    Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White)
                }
                Column(
                    Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        song.artist, fontSize = 12.sp, color = Color(0xFFE6BDC0),
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        song.title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                        color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.width(48.dp))
            }

            // big cover (tap = lyrics)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Cover(
                    song.cover,
                    Modifier
                        .align(Alignment.Center)
                        .padding(vertical = 20.dp)
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clickable { vm.showLyrics = true },
                    RoundedCornerShape(24.dp)
                )
            }

            // heart | lyrics, repeat, queue
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIcon(
                    if (vm.isLiked(song)) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder
                ) { vm.toggleLike(song) }
                Spacer(Modifier.weight(1f))
                RoundIcon(Icons.Filled.Subject) { vm.showLyrics = true }
                Spacer(Modifier.width(10.dp))
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (vm.repeat == 0) Color(0x33FFFFFF) else Color(0x88FFB3B9))
                        .clickable { vm.cycleRepeat() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (vm.repeat == 2) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        null, tint = Color.White, modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(Modifier.width(10.dp))
                RoundIcon(Icons.Filled.QueueMusic) { showQueue = true }
            }

            // progress
            val max = dur.coerceAtLeast(1L).toFloat()
            val shown = if (dragging) dragValue else pos.toFloat()
            Slider(
                value = shown.coerceIn(0f, max),
                onValueChange = { dragging = true; dragValue = it },
                onValueChangeFinished = {
                    vm.player.seekTo(dragValue.toLong())
                    pos = dragValue.toLong()
                    dragging = false
                },
                valueRange = 0f..max,
                colors = SliderDefaults.colors(
                    thumbColor = Pink,
                    activeTrackColor = Pink,
                    inactiveTrackColor = Color(0x55FFFFFF)
                )
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
                Text(fmt(shown.toLong()), fontSize = 12.sp, color = Color(0xFFE6BDC0))
                Spacer(Modifier.weight(1f))
                Text(fmt(dur), fontSize = 12.sp, color = Color(0xFFE6BDC0))
            }

            // controls
            Row(
                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.prev() }, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Filled.SkipPrevious, null, tint = Pink, modifier = Modifier.size(36.dp))
                }
                Spacer(Modifier.width(16.dp))
                Box(
                    Modifier.size(72.dp).clip(CircleShape).clickable { vm.toggle() },
                    contentAlignment = Alignment.Center
                ) {
                    if (vm.loading) {
                        CircularProgressIndicator(
                            Modifier.size(34.dp), color = Pink, strokeWidth = 3.dp
                        )
                    } else {
                        Icon(
                            if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            null, tint = Pink, modifier = Modifier.size(48.dp)
                        )
                    }
                }
                Spacer(Modifier.width(16.dp))
                IconButton(onClick = { vm.next() }, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Filled.SkipNext, null, tint = Pink, modifier = Modifier.size(36.dp))
                }
            }

            // bottom row
            Row(
                Modifier.fillMaxWidth().padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0x33FFFFFF))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.PhoneAndroid, null, tint = Pink, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("This phone", fontSize = 12.sp, color = Pink)
                }
                Spacer(Modifier.weight(1f))
                PlayerMenuButton(vm)
            }
        }

        AnimatedVisibility(
            visible = showQueue,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(350)) { it } + fadeIn(tween(250)),
            exit = slideOutVertically(tween(300)) { it } + fadeOut(tween(200))
        ) {
            QueuePanel(vm) { showQueue = false }
        }
    }
}

@Composable
private fun QueuePanel(vm: MainViewModel, onClose: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.62f)
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(Color(0xF2200B0F))
            .navigationBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Up next", fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                color = Color.White, modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White)
            }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp)) {
            itemsIndexed(vm.queue) { i, s ->
                val cur = i == vm.index
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (cur) Color(0x33FFB3B9) else Color.Transparent)
                        .clickable { vm.playFromQueue(i) }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Cover(s.cover, Modifier.size(44.dp), RoundedCornerShape(8.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            s.title, fontSize = 15.sp, color = Color.White,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            s.artist, fontSize = 12.sp, color = Color(0xFFE6BDC0),
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
