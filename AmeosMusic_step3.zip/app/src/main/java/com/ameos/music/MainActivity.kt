package com.ameos.music

import android.Manifest
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        if (Build.VERSION.SDK_INT >= 33) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            AmeosTheme {
                AmeosRoot(vm)
            }
        }
    }
}

@Composable
fun AmeosRoot(vm: MainViewModel) {
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF3A1511), Color(0xFF0E0B0B), Color(0xFF0A0808)),
                    endY = 1500f
                )
            )
    ) {
        Box(Modifier.fillMaxSize().statusBarsPadding()) {
            Crossfade(targetState = vm.tab, animationSpec = tween(260), label = "tabs") { t ->
                when (t) {
                    0 -> HomeScreen(vm)
                    1 -> SearchScreen(vm)
                    2 -> YourTypeScreen(vm)
                    else -> LibraryScreen(vm)
                }
            }
        }
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val err = vm.error
            if (err != null) {
                Text(err, color = Color(0xFFFFB4AB), fontSize = 12.sp)
            }
            MiniPlayer(vm)
            BottomBar(vm.tab, { vm.tab = it })
        }
        AnimatedVisibility(
            visible = vm.showPlayer && vm.current != null,
            enter = slideInVertically(tween(380)) { it } + fadeIn(tween(250)),
            exit = slideOutVertically(tween(320)) { it } + fadeOut(tween(200))
        ) {
            NowPlayingScreen(vm)
        }
        AnimatedVisibility(
            visible = vm.showSettings,
            enter = slideInHorizontally(tween(320)) { it } + fadeIn(tween(250)),
            exit = slideOutHorizontally(tween(280)) { it } + fadeOut(tween(200))
        ) {
            SettingsScreen(vm)
        }
    }
}
