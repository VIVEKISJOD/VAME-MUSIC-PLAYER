package com.ameos.music

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun Opt(label: String, onClick: () -> Unit) {
    Text(
        label, fontSize = 14.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0x22FFFFFF))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun Label(text: String) {
    Text(
        text, fontSize = 13.sp, color = Color(0xFFD9C0C2),
        modifier = Modifier.padding(top = 14.dp, bottom = 8.dp)
    )
}

@Composable
fun SleepDialog(vm: MainViewModel) {
    var customMin by remember { mutableStateOf("") }
    var customTimes by remember { mutableStateOf("") }
    val close = { vm.showSleepDialog = false }

    AlertDialog(
        onDismissRequest = { close() },
        confirmButton = { TextButton(onClick = { close() }) { Text("Close") } },
        title = { Text("Sleep and repeat") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (vm.sleepLeftSec > 0) {
                    val m = vm.sleepLeftSec / 60
                    val s = (vm.sleepLeftSec % 60).toString().padStart(2, '0')
                    Text("Timer running: $m:$s left", fontSize = 13.sp, color = Color(0xFFFFB3B9))
                }
                if (vm.sleepAfterSong) {
                    Text("Will stop when this song ends", fontSize = 13.sp, color = Color(0xFFFFB3B9))
                }
                if (vm.timesLeft > 0) {
                    Text("Plays left: ${vm.timesLeft}", fontSize = 13.sp, color = Color(0xFFFFB3B9))
                }

                Label("Sleep timer")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Opt("Off") { vm.setSleep(0); close() }
                    Opt("15 min") { vm.setSleep(15); close() }
                    Opt("30 min") { vm.setSleep(30); close() }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Opt("45 min") { vm.setSleep(45); close() }
                    Opt("60 min") { vm.setSleep(60); close() }
                    Opt("End of song") { vm.setSleep(0, true); close() }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextField(
                        value = customMin,
                        onValueChange = { customMin = it.filter { c -> c.isDigit() }.take(3) },
                        placeholder = { Text("Custom minutes") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Opt("Set") {
                        val n = customMin.toIntOrNull()
                        if (n != null && n > 0) {
                            vm.setSleep(n.coerceAtMost(600))
                            close()
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Let the song finish", fontSize = 15.sp)
                        Text(
                            "When time is up, the current song plays to its end first.",
                            fontSize = 12.sp, color = Color(0xFF8C7C7E)
                        )
                    }
                    Switch(checked = vm.finishSong, onCheckedChange = { vm.setFinishSongOn(it) })
                }

                Label("Play this song again and again, then stop")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Opt("1 time") { vm.playTimes(1); close() }
                    Opt("2 times") { vm.playTimes(2); close() }
                    Opt("3 times") { vm.playTimes(3); close() }
                    Opt("5 times") { vm.playTimes(5); close() }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextField(
                        value = customTimes,
                        onValueChange = { customTimes = it.filter { c -> c.isDigit() }.take(3) },
                        placeholder = { Text("Custom times") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Opt("Set") {
                        val n = customTimes.toIntOrNull()
                        if (n != null && n > 0) {
                            vm.playTimes(n.coerceAtMost(500))
                            close()
                        }
                    }
                }
                Text(
                    "The song restarts from the beginning, plays that many times, then stops.",
                    fontSize = 12.sp, color = Color(0xFF8C7C7E),
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    )
}
