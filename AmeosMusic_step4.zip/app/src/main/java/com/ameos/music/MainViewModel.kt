package com.ameos.music

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val player = PlayerHolder.get(app)

    // navigation: 0 Home, 1 Search, 2 Your Type, 3 Library
    var tab by mutableIntStateOf(0)
    var showPlayer by mutableStateOf(false)
    var showSettings by mutableStateOf(false)
    var showLyrics by mutableStateOf(false)
    var showSleepDialog by mutableStateOf(false)
    var showMenu by mutableStateOf(false)
    var homeFilter by mutableIntStateOf(0)

    var query by mutableStateOf("")
    var results by mutableStateOf<List<Song>>(emptyList())
    var searched by mutableStateOf(false)

    var recommended by mutableStateOf<List<Song>>(emptyList())
    var discover by mutableStateOf<List<Song>>(emptyList())
    var podcasts by mutableStateOf<List<Song>>(emptyList())
    var suggestions by mutableStateOf<List<Song>>(emptyList())
    var played = mutableStateListOf<Song>()
    val liked = mutableStateListOf<Song>()

    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var current by mutableStateOf<Song?>(null)
    var isPlaying by mutableStateOf(false)

    var lyrics by mutableStateOf<List<LyricLine>>(emptyList())
    var lyricsSynced by mutableStateOf(false)
    var lyricsLoading by mutableStateOf(false)

    // settings
    var title by mutableStateOf(Prefs.title(app))
    var endless by mutableStateOf(Prefs.endless(app))

    // playback modes: repeat 0 off, 1 all, 2 one
    var repeat by mutableIntStateOf(0)
    var sleepLeftSec by mutableIntStateOf(0)
    var sleepAfterSong by mutableStateOf(false)
    var timesLeft by mutableIntStateOf(0)
    var finishSong by mutableStateOf(Prefs.finishSong(app))

    var queue by mutableStateOf<List<Song>>(emptyList())
        private set
    var index by mutableIntStateOf(0)
        private set

    private val cache = HashMap<String, Resolved>()
    private var startJob: Job? = null
    private var lyricsJob: Job? = null
    private var sleepJob: Job? = null

    init {
        liked.addAll(Prefs.likes(app))
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) onEnded()
            }

            override fun onPlayerError(e: PlaybackException) {
                error = "Play nahi hua: " + (e.message ?: e.errorCodeName)
            }
        })
        isPlaying = player.isPlaying
        PlaybackBridge.onNext = { next() }
        PlaybackBridge.onPrev = { prev() }
        loadHome()
    }

    override fun onCleared() {
        PlaybackBridge.onNext = null
        PlaybackBridge.onPrev = null
        super.onCleared()
    }

    // ---------- loading lists ----------

    fun loadHome() {
        viewModelScope.launch {
            try {
                recommended = MusicRepo.search("top songs 2026")
            } catch (e: Exception) {
                error = "Home load fail: " + (e.message ?: e.javaClass.simpleName)
            }
        }
    }

    fun loadDiscover() {
        viewModelScope.launch {
            loading = true
            try {
                discover = MusicRepo.search("new music this week")
            } catch (e: Exception) {
                error = "Discover fail: " + (e.message ?: e.javaClass.simpleName)
            }
            loading = false
        }
    }

    fun loadPodcasts() {
        viewModelScope.launch {
            try {
                podcasts = MusicRepo.search("podcast episodes")
            } catch (e: Exception) {
                error = "Podcast load fail: " + (e.message ?: e.javaClass.simpleName)
            }
        }
    }

    fun pickFilter(i: Int) {
        homeFilter = i
        if (i == 2 && podcasts.isEmpty()) loadPodcasts()
    }

    fun search() {
        val q = query.trim()
        if (q.isEmpty()) return
        viewModelScope.launch {
            loading = true
            error = null
            searched = true
            try {
                results = MusicRepo.search(q)
                if (results.isEmpty()) error = "Kuch nahi mila"
            } catch (e: Exception) {
                error = "Search fail: " + (e.message ?: e.javaClass.simpleName)
            }
            loading = false
        }
    }

    fun searchFor(text: String) {
        query = text
        search()
    }

    // ---------- settings ----------

    fun updateTitle(t: String) {
        title = t
        Prefs.setTitle(getApplication<Application>(), t)
    }

    fun setEndlessOn(on: Boolean) {
        endless = on
        Prefs.setEndless(getApplication<Application>(), on)
    }

    // ---------- queue / playback ----------

    fun play(song: Song, list: List<Song> = listOf(song)) {
        queue = list
        index = list.indexOf(song).coerceAtLeast(0)
        start(song)
    }

    fun playFromQueue(i: Int) {
        if (i !in queue.indices) return
        index = i
        start(queue[i])
    }

    fun next() {
        if (queue.isEmpty()) return
        index = (index + 1) % queue.size
        start(queue[index])
    }

    fun prev() {
        if (queue.isEmpty()) return
        if (player.currentPosition > 3000) {
            player.seekTo(0)
            return
        }
        index = if (index - 1 < 0) queue.size - 1 else index - 1
        start(queue[index])
    }

    fun cycleRepeat() {
        repeat = (repeat + 1) % 3
    }

    fun shuffleQueue() {
        val cur = current ?: return
        if (queue.size < 2) return
        queue = listOf(cur) + queue.filter { it.url != cur.url }.shuffled()
        index = 0
        prefetchNext()
    }

    fun playNext(song: Song) {
        if (queue.isEmpty() || current == null) {
            play(song)
            return
        }
        val list = queue.toMutableList()
        list.add((index + 1).coerceAtMost(list.size), song)
        queue = list
        prefetchNext()
    }

    fun addToQueue(song: Song) {
        if (queue.isEmpty() || current == null) {
            play(song)
            return
        }
        queue = queue + song
    }

    fun startRadio() {
        val cur = current ?: return
        viewModelScope.launch {
            try {
                val r = resolveFor(cur)
                val more = r.related.filter { it.url != cur.url }.take(25)
                if (more.isNotEmpty()) {
                    queue = listOf(cur) + more
                    index = 0
                    prefetchNext()
                }
            } catch (e: Exception) {
            }
        }
    }

    fun setSleep(minutes: Int, afterSong: Boolean = false) {
        sleepJob?.cancel()
        sleepAfterSong = afterSong
        sleepLeftSec = minutes * 60
        if (minutes <= 0) return
        sleepJob = viewModelScope.launch {
            while (sleepLeftSec > 0) {
                delay(1000)
                sleepLeftSec--
            }
            if (finishSong && player.isPlaying) {
                sleepAfterSong = true
            } else {
                player.pause()
            }
        }
    }

    fun setFinishSongOn(on: Boolean) {
        finishSong = on
        Prefs.setFinishSong(getApplication<Application>(), on)
    }

    // play the current song n times from the start, then stop
    fun playTimes(n: Int) {
        if (current == null) return
        timesLeft = n.coerceAtLeast(1)
        player.seekTo(0)
        player.play()
    }

    private fun onEnded() {
        if (sleepAfterSong) {
            sleepAfterSong = false
            timesLeft = 0
            return
        }
        if (timesLeft > 0) {
            timesLeft--
            if (timesLeft > 0) {
                player.seekTo(0)
                player.play()
            }
            return
        }
        if (repeat == 2) {
            player.seekTo(0)
            player.play()
            return
        }
        val last = index >= queue.size - 1
        if (last && repeat == 0 && !endless) return
        next()
    }

    private suspend fun resolveFor(song: Song): Resolved {
        val cached = cache[song.url]
        if (cached != null) return cached
        val fresh = MusicRepo.resolve(song.url)
        cache[song.url] = fresh
        return fresh
    }

    private fun prefetchNext() {
        if (queue.size < 2) return
        val n = queue[(index + 1) % queue.size]
        if (cache.containsKey(n.url)) return
        viewModelScope.launch {
            try {
                resolveFor(n)
            } catch (e: Exception) {
            }
        }
    }

    private fun loadLyrics(song: Song) {
        lyricsJob?.cancel()
        lyrics = emptyList()
        lyricsSynced = false
        lyricsLoading = true
        lyricsJob = viewModelScope.launch {
            try {
                val r = LyricsRepo.fetch(song.title, song.artist, song.durationSec)
                lyrics = r.lines
                lyricsSynced = r.synced
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
            }
            lyricsLoading = false
        }
    }

    private fun start(song: Song) {
        startJob?.cancel()
        player.pause()
        timesLeft = 0
        current = song
        loading = true
        error = null
        loadLyrics(song)
        startJob = viewModelScope.launch {
            try {
                val r = resolveFor(song)
                val meta = MediaMetadata.Builder()
                    .setTitle(song.title)
                    .setArtist(song.artist)
                    .apply {
                        if (song.cover != null) setArtworkUri(Uri.parse(song.cover))
                    }
                    .build()
                val item = MediaItem.Builder()
                    .setUri(r.audio)
                    .setMediaMetadata(meta)
                    .build()
                player.setMediaItem(item)
                player.prepare()
                player.play()
                played.removeAll { it.url == song.url }
                played.add(0, song)

                suggestions = r.related.take(10)
                if (endless && queue.size - index < 8) {
                    val have = queue.map { it.url }.toSet()
                    val more = r.related.filter { it.url !in have }.take(10)
                    if (more.isNotEmpty()) queue = queue + more
                }

                val ctx = getApplication<Application>()
                ctx.startService(Intent(ctx, PlaybackService::class.java))
                prefetchNext()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Play fail: " + e.javaClass.simpleName + " | " + (e.message ?: "-")
            }
            loading = false
        }
    }

    fun toggle() {
        if (player.isPlaying) player.pause() else player.play()
    }

    fun isLiked(song: Song): Boolean = liked.any { it.url == song.url }

    fun toggleLike(song: Song) {
        if (isLiked(song)) liked.removeAll { it.url == song.url } else liked.add(0, song)
        Prefs.saveLikes(getApplication<Application>(), liked.toList())
    }
}
