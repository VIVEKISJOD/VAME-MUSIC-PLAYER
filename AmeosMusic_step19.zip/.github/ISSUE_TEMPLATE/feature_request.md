---
name: Feature request
about: Suggest an idea
title: "[Idea] "
labels: enhancement
---

**What would you like VAME to do?**

**Why would it help?**
