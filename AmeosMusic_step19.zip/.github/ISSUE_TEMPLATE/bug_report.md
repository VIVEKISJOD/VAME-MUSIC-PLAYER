---
name: Bug report
about: Something is not working
title: "[Bug] "
labels: bug
---

**What happened?**

**What did you expect?**

**Steps to repeat it**
1.
2.

**Phone and Android version**

**VAME version** (Settings > About)
