package com.ameos.music

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

data class Song(
    val title: String,
    val artist: String,
    val url: String,
    val cover: String?,
    val durationSec: Long
)

data class Resolved(val audio: String, val related: List<Song>)

data class Album(val title: String, val artist: String, val url: String, val cover: String?)

data class PlaylistData(val name: String, val artist: String, val cover: String?, val songs: List<Song>)

object MusicRepo {

    // "Official songs only": hides remixes, slowed/reverb, lofi, covers, karaoke, mashups
    // and fan/lyrics channels. Set from Settings (MainViewModel keeps it in sync).
    @Volatile
    var officialOnly: Boolean = true

    // audio quality: 0 high, 1 normal, 2 data saver
    @Volatile
    var quality: Int = 0

    // words that are junk anywhere in the title
    private val strongJunk = Regex(
        "\\b(remix|remixed|slowed|reverb|sped up|speed up|speedup|nightcore|mashup|karaoke|" +
            "lofi|lo-fi|8d|bass boosted|bass boost|bootleg|unofficial|tiktok|ringtone|" +
            "whatsapp status|jhankar|tapori)\\b",
        RegexOption.IGNORE_CASE
    )

    // words that are junk only in the (brackets) / - dash / | pipe part of the title
    private val weakJunk = Regex(
        "\\b(cover|dj|mix|instrumental|flip|edit by|version by)\\b",
        RegexOption.IGNORE_CASE
    )

    // channels that are not the artist or the label
    private val junkChannel = Regex(
        "\\b(lyrics|lyrical|lofi|lo-fi|remix|remixes|slowed|reverb|nightcore|8d|karaoke|" +
            "mashup|cover|covers|fan made|unofficial|status|ringtones)\\b",
        RegexOption.IGNORE_CASE
    )

    private fun isOfficial(s: Song): Boolean {
        val t = s.title
        if (strongJunk.containsMatchIn(t)) return false
        val cut = t.indexOfFirst { it == '(' || it == '[' || it == '-' || it == '|' }
        if (cut >= 0 && weakJunk.containsMatchIn(t.substring(cut))) return false
        if (junkChannel.containsMatchIn(s.artist)) return false
        return true
    }

    // if the person typed remix/slowed/lofi themselves, they want those, so do not filter
    private fun applyFilter(list: List<Song>, query: String?): List<Song> {
        if (!officialOnly) return list
        if (query != null && strongJunk.containsMatchIn(query)) return list
        val clean = list.filter { isOfficial(it) }
        return if (clean.isEmpty()) list else clean
    }

    suspend fun search(query: String): List<Song> = withContext(Dispatchers.IO) {
        val extractor = ServiceList.YouTube.getSearchExtractor(
            query,
            listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS),
            ""
        )
        extractor.fetchPage()
        val all = extractor.initialPage.items
            .filterIsInstance<StreamInfoItem>()
            .map { toSong(it) }
        applyFilter(all, query)
    }

    // albums (YouTube Music "Albums" search)
    suspend fun searchAlbums(query: String): List<Album> = withContext(Dispatchers.IO) {
        val extractor = ServiceList.YouTube.getSearchExtractor(
            query,
            listOf(YoutubeSearchQueryHandlerFactory.MUSIC_ALBUMS),
            ""
        )
        extractor.fetchPage()
        extractor.initialPage.items
            .filterIsInstance<PlaylistInfoItem>()
            .map {
                Album(
                    title = it.name ?: "Album",
                    artist = it.uploaderName ?: "",
                    url = it.url,
                    cover = bigCover(it.thumbnails.maxByOrNull { t -> t.height }?.url)
                )
            }
    }

    // all songs of an album / playlist link (used by Album page and Import playlist)
    suspend fun playlistSongs(url: String, maxItems: Int = 200): PlaylistData =
        withContext(Dispatchers.IO) {
            val info = PlaylistInfo.getInfo(url)
            val out = ArrayList<Song>()
            for (item in info.relatedItems) {
                if (item is StreamInfoItem) out.add(toSong(item))
            }
            var next = info.nextPage
            var guard = 0
            while (next != null && out.size < maxItems && guard < 6) {
                val page = PlaylistInfo.getMoreItems(ServiceList.YouTube, url, next)
                for (item in page.items) {
                    if (item is StreamInfoItem) out.add(toSong(item))
                }
                next = page.nextPage
                guard++
            }
            PlaylistData(
                name = info.name ?: "Playlist",
                artist = (info.uploaderName ?: "").ifBlank { out.firstOrNull()?.artist ?: "" },
                cover = out.firstOrNull()?.cover,
                songs = out
            )
        }

    suspend fun resolve(videoUrl: String, q: Int = quality): Resolved = withContext(Dispatchers.IO) {
        val info = StreamInfo.getInfo(videoUrl)
        val streams = info.audioStreams
        val progressive = streams.filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
        val pool = if (progressive.isNotEmpty()) progressive else streams
        val known = pool.filter { it.averageBitrate > 0 }
        val sorted = (if (known.isNotEmpty()) known else pool).sortedBy { it.averageBitrate }
        val best = when (q) {
            2 -> sorted.firstOrNull()
            1 -> sorted.getOrNull(sorted.size / 2)
            else -> sorted.lastOrNull()
        } ?: throw IllegalStateException("Is song ki audio nahi mili")
        val related = try {
            val all = info.relatedItems
                .filterIsInstance<StreamInfoItem>()
                .filter { it.duration in 60L..600L }
                .map { toSong(it) }
            if (officialOnly) all.filter { isOfficial(it) } else all
        } catch (e: Exception) {
            emptyList()
        }
        Resolved(best.content, related)
    }

    private fun toSong(item: StreamInfoItem): Song = Song(
        title = item.name ?: "Unknown",
        artist = item.uploaderName ?: "",
        url = item.url,
        cover = bigCover(item.thumbnails.maxByOrNull { it.height }?.url),
        durationSec = item.duration
    )

    private fun bigCover(url: String?): String? {
        if (url == null) return null
        return if (url.contains("googleusercontent.com") || url.contains("ggpht.com")) {
            url.replace(Regex("=w\\d+-h\\d+.*$"), "=w600-h600-l90-rj")
        } else {
            url
        }
    }
}
