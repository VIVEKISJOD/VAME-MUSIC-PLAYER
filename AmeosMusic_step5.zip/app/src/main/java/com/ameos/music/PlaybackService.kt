package com.ameos.music

import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

object PlaybackBridge {
    var onNext: (() -> Unit)? = null
    var onPrev: (() -> Unit)? = null
}

private class QueuePlayer(p: Player) : ForwardingPlayer(p) {
    private val extra = intArrayOf(
        Player.COMMAND_SEEK_TO_NEXT,
        Player.COMMAND_SEEK_TO_PREVIOUS,
        Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
        Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM
    )

    override fun getAvailableCommands(): Player.Commands =
        super.getAvailableCommands().buildUpon().addAll(*extra).build()

    override fun isCommandAvailable(command: Int): Boolean =
        extra.contains(command) || super.isCommandAvailable(command)

    override fun seekToNext() {
        PlaybackBridge.onNext?.invoke()
    }

    override fun seekToNextMediaItem() {
        PlaybackBridge.onNext?.invoke()
    }

    override fun seekToPrevious() {
        PlaybackBridge.onPrev?.invoke()
    }

    override fun seekToPreviousMediaItem() {
        PlaybackBridge.onPrev?.invoke()
    }
}

class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val s = MediaSession.Builder(this, QueuePlayer(PlayerHolder.get(this))).build()
        session = s
        addSession(s)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        session?.release()
        session = null
        super.onDestroy()
    }
}
