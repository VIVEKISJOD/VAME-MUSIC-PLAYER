package com.ameos.music

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val ScreenPad = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 200.dp)

@Composable
fun ScreenTitle(text: String, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, fontSize = 34.sp, fontWeight = FontWeight.SemiBold, color = Color.White,
            modifier = Modifier.weight(1f))
        trailing()
    }
}

// ---------------- HOME ----------------

@Composable
fun HomeScreen(vm: MainViewModel) {
    val hero = vm.current ?: vm.recommended.firstOrNull()
    val recs = vm.recommended.drop(1).take(4)
    val lastAlbums = if (vm.played.size > 1) vm.played.toList() else vm.recommended.drop(5)

    LazyColumn(contentPadding = ScreenPad) {
        item {
            ScreenTitle(vm.title.ifBlank { "Music" }) {
                Icon(
                    Icons.Filled.AccountCircle, null, tint = Color.White,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .clickable { vm.showSettings = true }
                )
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Music", "Podcasts", "Playlists").forEachIndexed { i, t ->
                    val chipBg by animateColorAsState(
                        if (i == vm.homeFilter) Color(0xFF7A1A24) else Color(0x22FFFFFF),
                        label = "chip"
                    )
                    Text(
                        t, fontSize = 14.sp, color = Color.White,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(chipBg)
                            .clickable { vm.pickFilter(i) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
        if (vm.homeFilter == 0) {
        item { SectionLabel("Last Played") }
        item {
            if (hero != null) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .border(1.dp, Color(0x33FF6B7A), RoundedCornerShape(24.dp))
                        .clickable { vm.play(hero, vm.recommended) }
                ) {
                    Cover(hero.cover, Modifier.fillMaxSize(), RoundedCornerShape(0.dp))
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC200A0E)))
                        )
                    )
                    Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                        Text(hero.title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                            color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 200.dp))
                        Text(hero.artist, fontSize = 14.sp, color = Color(0xFFE6BDC0), maxLines = 1)
                    }
                    Row(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .padding(14.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x66FFFFFF))
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Replay", color = Color.White, fontSize = 14.sp)
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            } else {
                Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF2A1215)))
            }
        }
        item { SectionLabel("Recommended Albums", "NEW") }
        item {
            val rows = recs.chunked(2)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                rows.forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { s ->
                            Row(
                                Modifier.weight(1f).clickable { vm.play(s, vm.recommended) },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Cover(s.cover, Modifier.size(48.dp), RoundedCornerShape(8.dp))
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(s.title, fontSize = 15.sp, color = Color.White,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(s.artist, fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item { SectionLabel("Last played albums") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(lastAlbums) { s ->
                    Column(Modifier.width(150.dp).clickable { vm.play(s, lastAlbums) }) {
                        Cover(s.cover, Modifier.size(150.dp), RoundedCornerShape(16.dp))
                        Text(s.title, fontSize = 14.sp, color = Color.White, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                        Text(s.artist, fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                            overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        if (vm.suggestions.isNotEmpty()) {
            item { SectionLabel("Suggested for you") }
            items(vm.suggestions.take(6)) { s -> SongRow(s, vm, vm.suggestions) }
        }
        }
        if (vm.homeFilter == 1) {
            item { SectionLabel("Songs for you") }
            items(vm.recommended) { s -> SongRow(s, vm, vm.recommended) }
        }
        if (vm.homeFilter == 2) {
            item { SectionLabel("Podcasts") }
            if (vm.podcasts.isEmpty()) {
                item { Text("Loading...", color = Color(0xFFE6BDC0)) }
            }
            items(vm.podcasts) { s -> SongRow(s, vm, vm.podcasts) }
        }
        if (vm.homeFilter == 3) {
            item { SectionLabel("Playlists") }
            item {
                TwoColumn(listOf("Daily", "Bangers", "Evening")) { n, m ->
                    LibItem(m, n, null, null) {
                        vm.searchFor("$n songs")
                        vm.tab = 1
                    }
                }
            }
        }
    }
}

// ---------------- SEARCH ----------------

@Composable
fun SearchScreen(vm: MainViewModel) {
    val tiles = listOf(
        "Rap" to Color(0xFF3B3B3B),
        "Alternative/Indie" to Color(0xFF2E5A6B),
        "Pop" to Color(0xFF8A2B6B),
        "Hip-Hop" to Color(0xFF5A3A12)
    )
    LazyColumn(contentPadding = ScreenPad) {
        item { ScreenTitle("Search") }
        item {
            TextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                placeholder = { Text("Search for Music...") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.search() }),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0x33FFFFFF),
                    unfocusedContainerColor = Color(0x33FFFFFF),
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (vm.loading) {
            item {
                Text("Loading...", color = Color(0xFFE6BDC0), modifier = Modifier.padding(top = 12.dp))
            }
        }
        if (!vm.searched) {
            item { SectionLabel("Recommended") }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    tiles.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { (name, col) ->
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .height(130.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(col)
                                        .clickable { vm.searchFor("$name music") }
                                        .padding(12.dp)
                                ) {
                                    Text(name, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                                        color = Color.White, modifier = Modifier.align(Alignment.BottomStart))
                                }
                            }
                        }
                    }
                }
            }
        } else {
            items(vm.results) { s -> SongRow(s, vm, vm.results) }
        }
    }
}

// ---------------- YOUR TYPE ----------------

@Composable
fun YourTypeScreen(vm: MainViewModel) {
    LazyColumn(contentPadding = ScreenPad) {
        item { ScreenTitle("Your Type") }
        if (vm.discover.isEmpty()) {
            item {
                Column(
                    Modifier.fillMaxWidth().padding(top = 80.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Discover new Music", fontSize = 26.sp, fontWeight = FontWeight.SemiBold,
                        color = Color.White, textAlign = TextAlign.Center)
                    Text("Powered by AmeOS", fontSize = 13.sp, color = Color(0xFF8C7C7E),
                        modifier = Modifier.padding(top = 4.dp))
                    Spacer(Modifier.height(80.dp))
                    Text("We're ready, user.", fontSize = 16.sp, color = Color.White)
                    Spacer(Modifier.height(10.dp))
                    Box(
                        Modifier.size(48.dp).clip(CircleShape)
                            .background(Color(0x22FFFFFF))
                            .clickable { vm.loadDiscover() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White,
                            modifier = Modifier.size(30.dp))
                    }
                }
            }
        } else {
            items(vm.discover) { s -> SongRow(s, vm, vm.discover) }
        }
    }
}

// ---------------- LIBRARY ----------------

@Composable
private fun <T> TwoColumn(list: List<T>, cell: @Composable (T, Modifier) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        list.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { c -> cell(c, Modifier.weight(1f)) }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun LibItem(
    modifier: Modifier, title: String, sub: String?, cover: String?,
    circle: Boolean = false, onClick: () -> Unit
) {
    Row(modifier.clickable { onClick() }, verticalAlignment = Alignment.CenterVertically) {
        Cover(cover, Modifier.size(46.dp), if (circle) CircleShape else RoundedCornerShape(10.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, fontSize = 15.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub != null) {
                Text(sub, fontSize = 11.sp, color = Color(0xFF8C7C7E), maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun LibraryScreen(vm: MainViewModel) {
    val artists = vm.liked.map { it.artist }.distinct().take(4)
    val songs = vm.liked.take(3)
    val names = listOf("Daily", "Bangers", "Evening")
    LazyColumn(contentPadding = ScreenPad) {
        item { ScreenTitle("Library") }
        item { SectionLabel("Playlists") }
        item {
            TwoColumn(names) { n, m ->
                LibItem(m, n, null, vm.played.getOrNull(names.indexOf(n))?.cover) {
                    vm.searchFor("$n songs")
                    vm.tab = 1
                }
            }
        }
        item { SectionLabel("Liked Artists") }
        item {
            if (artists.isEmpty()) {
                Text("Heart a song to see artists here", fontSize = 13.sp, color = Color(0xFF8C7C7E))
            } else {
                TwoColumn(artists) { a, m ->
                    LibItem(m, a, null, vm.liked.first { it.artist == a }.cover, true) {
                        vm.searchFor(a)
                        vm.tab = 1
                    }
                }
            }
        }
        item { SectionLabel("Liked Songs") }
        item {
            if (songs.isEmpty()) {
                Text("No liked songs yet", fontSize = 13.sp, color = Color(0xFF8C7C7E))
            } else {
                TwoColumn(songs) { s, m ->
                    LibItem(m, s.title, s.artist, s.cover) { vm.play(s, vm.liked.toList()) }
                }
            }
        }
    }
}
