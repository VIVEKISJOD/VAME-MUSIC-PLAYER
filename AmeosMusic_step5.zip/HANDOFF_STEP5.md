# AMEOS MUSIC HANDOFF - ZIP step5 (v0.3.3) + FULL ROADMAP (22 Oct 2026)
NOTE: zip numbers (step4, step5...) are NOT the roadmap step numbers below. Zip step5 = small fixes (v0.3.3). Roadmap Step 4 (Figma redo) is still not done. New rule from user: with EVERY file/zip always include a handoff md and a small changelog list.
Read with HANDOFF_STEP1.md, HANDOFF_UPDATE_21Oct.md, CHANGELOG.md. Rules: do not greet like new, ONE question per message, short replies, never ask user to edit code, full zips (new name each time AmeosMusic_stepN.zip, build.yml takes the highest N), a handoff with every file, ALWAYS give the user a short list of what was fixed/added with every change. Claude cannot compile (no network to Google/Maven); user builds on GitHub Actions and pastes errors. Check brace balance before sending.

## State (updated for Step 4)
- User built Step 3 on GitHub Actions and CONFIRMED IT WORKS. Step 4 = Step 3 + lyrics top pill goes back to cover + new QuickSheet.kt bottom sheet (replaces dropdown in PlayerMenuButton; state vm.showMenu; vm.playNext/addToQueue/startRadio added). Step 4 not yet compiled by user: risky spots are icon names (PlaylistAdd, QueuePlayNext, OndemandVideo, GraphicEq, Bedtime, Radio) and AudioEffect intent.
- User asked WHEN playlist creation etc. will come. Answer given: Step 5 = playlists with custom cover + persistence + onboarding; but Step 4 UI redo (Figma Home/Search/Your Type/Library + glass) comes first per Order below.

## Zip step5 (v0.3.3) state
- User confirmed step4 zip compiled and showed the quick sheet; reported bugs, fixed in step5: sheet now drag-down-to-close (QuickSheet.kt), BackHandler for sheet moved inside the visible sheet so it wins over Now Playing, SleepDialog.kt rewritten as custom Dialog, CoverColor.kt (rememberCoverTint, no palette lib) tints Now Playing and Lyrics, Up next queue drag reorder (QueuePanel in NowPlaying.kt, vm.moveInQueue/reorderDone), SongRow has play-next button (vm.playNext dedupes). Not yet compiled by user. Risky spots: Modifier.animateItem() (foundation 1.7), TextFieldDefaults.colors params, detectDragGestures in LazyColumn.

## Old state (Step 3)
- User confirmed Step 1.1 plays songs. User has NOT yet uploaded step2 or step3; he said he will upload step3 after more is added. step3 zip = Step 2 + notification fix + loop/sleep/endless/queue/settings/animations (see CHANGELOG.md). If the build fails, user pastes errors; likely risky spots: NewPipe `info.relatedItems` name, ForwardingPlayer overrides in PlaybackService.kt, deprecated icons.

## Added at 00:55 (see CHANGELOG.md)
LyricsScreen.kt (new lyrics UI), SleepDialog.kt (custom timer, let-song-finish, play N times), PlayerMenuButton shared, instant song switch. v0.3.1. Still not uploaded/compiled by user.

## User's feature list (never forget)
- No account ever. First-launch onboarding "what type of songs do you like?" feeding Home/Search/Your Type.
- Settings page (must) - started (title rename, endless). More: audio quality, download quality, clear cache, Hinglish toggle.
- Playlists: user can CREATE playlists with CUSTOM COVER (photo picker), real and persistent. Library playlists are currently fake (Daily/Bangers/Evening just search).
- Your Type: currently only a generic search "new music this week"; rebuild from onboarding taste + history. User asked if it works.
- OFFLINE: download songs, play offline, Downloads screen.
- Lyrics in HINGLISH for Hindi songs: android.icu Transliterator "Devanagari-Latin; Latin-ASCII", toggle in Settings.
- SMOOTHEST animations everywhere (shared cover transition mini player -> Now Playing, press scale, springs).
- LIQUID / SOFT GLASS look (translucent layers, light edge, blur on Android 12+). Asked user Android version, no answer yet.
- UI must match AmeOS 16 Figma screenshots exactly (7 screenshots: Home, Search, Your Type, Library, album page, artist/song page, Daily playlist page, Now Playing, Lyrics, "..." menu). Credit AmeOS team CC BY 4.0 (done in Settings About).

## Order
- Step 4: Home/Search/Your Type/Library redone to Figma + glass look + more animations + album/artist/playlist pages.
- Step 5: playlist creation with custom cover + persistence of playlists/last played + onboarding page.
- Step 6: offline downloads + offline playback.
- Step 7: Hinglish lyrics toggle, Animate cover, full Settings, final polish.
