# VAME Music changelog

## Step 5 zip (v0.3.3) - fixes on top of Step 4 zip (22 Oct 2026)
Fixed
- Quick settings sheet: drag the little pill (or the area around it) down to close it.
- Back button now closes the quick settings sheet FIRST (before the cover page).
- Sleep and repeat dialog redesigned: rounded card, big chips, status card with Cancel, custom boxes with Set button, Done button.
Added
- Now Playing and Lyrics background colour now follows the song cover colour (smooth fade).
- Up next queue: drag the handle on the right of a song to change the order (current song stays tracked).
- Quick "play next" button on every song row (next to the heart). Tap = plays right after the current song, no duplicates.

## Step 4 (v0.3.2) - small fixes on top of Step 3 (user confirmed Step 3 works, 22 Oct 2026)
Fixed
- Top pill on the Lyrics screen now takes you back to the song cover (Now Playing).
Added
- New quick settings bottom sheet instead of the small "..." dropdown (Now Playing and Lyrics). Opens from the "..." button, tap outside or Back to close.
  - Header with cover, title, artist.
  - Big buttons: Add to playlist (placeholder, coming next), Download (placeholder, coming later), Share (works).
  - Playback: Start radio, Play next, Add to queue, Watch video (opens YouTube), Audio Effects (phone equalizer), Sleep Timer, Shuffle, Endless on/off.
  - Go to: artist (opens Search for the artist).
  - Recommendations: suggested songs, tap to play.

## Step 3 (v0.3) - NOT yet uploaded by user as of 22 Oct 2026 00:50 (includes Step 2 too)
Fixed
- Music now shows in the notification, lock screen and Xiaomi HyperOS island (session was never added to the service). Notification Next/Prev buttons work with the app queue.
- Home chips (All / Music / Podcasts / Playlists) now work.
- Top-right user icon now opens Settings.
Added
- Now Playing screen (pill opens it) + synced Lyrics view + "..." menu (Open in Music app, Karaoke mode, Shuffle).
- Loop button: off / all / one.
- Sleep timer: 15/30/45/60 min or end of song (in "..." menu).
- Endless queue: when the queue is nearly done, similar songs are added automatically. Toggle in "..." menu and Settings.
- "Up next" queue panel (queue icon in Now Playing), tap a song to jump.
- "Suggested for you" on Home, based on the song you played.
- Settings page: type your own Home title (replaces "Music"), endless toggle, About with AmeOS credit.
- Likes are now saved on the phone (survive closing the app). Title and endless setting saved too.
- Animations: tab fade, Now Playing slides up, Settings slides in, queue panel slides up, covers fade in, chip colour animates.
- Faster playback: song shows instantly, next song's link is prepared in advance.
Added after user feedback (00:55)
- Dedicated lyrics button in Now Playing (also tap the cover). New full-screen Lyrics screen like the user's reference: dark background, current line big and white, other lines blurred (blur only on Android 12+), current line fills in word by word, tap a line to jump, top pill with song, bottom back / big play-pause / more buttons.
- Picking a new song: pill and screens switch to the new song instantly, old song pauses at once, loading circle shows until the new one starts.
- Sleep timer has a Custom minutes box.
- "Let the song finish" switch: when the timer ends, the current song plays to its end instead of cutting off mid-song (on by default).
- "Play this song N times, then stop": 1, 2, 3, 5 or custom times (e.g. Hanuman Chalisa 3 times). Song restarts from the start, plays N times fully, then stops.
- Menu item renamed "Sleep and repeat".

Not yet (next steps): Figma-exact Home/Library redesign + glass look, album/artist/playlist pages, playlist creation with custom cover, onboarding page, offline downloads, Hinglish lyrics.
