package com.ameos.music

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val player = PlayerHolder.get(app)

    // navigation: 0 Home, 1 Search, 2 Your Type, 3 Library
    var tab by mutableIntStateOf(0)

    var query by mutableStateOf("")
    var results by mutableStateOf<List<Song>>(emptyList())
    var searched by mutableStateOf(false)

    var recommended by mutableStateOf<List<Song>>(emptyList())
    var discover by mutableStateOf<List<Song>>(emptyList())
    var played = mutableStateListOf<Song>()
    val liked = mutableStateListOf<Song>()

    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var current by mutableStateOf<Song?>(null)
    var isPlaying by mutableStateOf(false)

    private var queue: List<Song> = emptyList()
    private var index = 0

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) next()
            }

            override fun onPlayerError(e: PlaybackException) {
                error = "Play nahi hua: " + (e.message ?: e.errorCodeName)
            }
        })
        isPlaying = player.isPlaying
        loadHome()
    }

    fun loadHome() {
        viewModelScope.launch {
            try {
                recommended = MusicRepo.search("top songs 2026")
            } catch (e: Exception) {
                error = "Home load fail: " + (e.message ?: e.javaClass.simpleName)
            }
        }
    }

    fun loadDiscover() {
        viewModelScope.launch {
            loading = true
            try {
                discover = MusicRepo.search("new music this week")
            } catch (e: Exception) {
                error = "Discover fail: " + (e.message ?: e.javaClass.simpleName)
            }
            loading = false
        }
    }

    fun search() {
        val q = query.trim()
        if (q.isEmpty()) return
        viewModelScope.launch {
            loading = true
            error = null
            searched = true
            try {
                results = MusicRepo.search(q)
                if (results.isEmpty()) error = "Kuch nahi mila"
            } catch (e: Exception) {
                error = "Search fail: " + (e.message ?: e.javaClass.simpleName)
            }
            loading = false
        }
    }

    fun searchFor(text: String) {
        query = text
        search()
    }

    fun play(song: Song, list: List<Song> = listOf(song)) {
        queue = list
        index = list.indexOf(song).coerceAtLeast(0)
        start(song)
    }

    fun next() {
        if (queue.isEmpty()) return
        index = (index + 1) % queue.size
        start(queue[index])
    }

    fun prev() {
        if (queue.isEmpty()) return
        if (player.currentPosition > 3000) {
            player.seekTo(0)
            return
        }
        index = if (index - 1 < 0) queue.size - 1 else index - 1
        start(queue[index])
    }

    private fun start(song: Song) {
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val streamUrl = MusicRepo.audioUrl(song.url)
                val meta = MediaMetadata.Builder()
                    .setTitle(song.title)
                    .setArtist(song.artist)
                    .apply {
                        if (song.cover != null) setArtworkUri(Uri.parse(song.cover))
                    }
                    .build()
                val item = MediaItem.Builder()
                    .setUri(streamUrl)
                    .setMediaMetadata(meta)
                    .build()
                player.setMediaItem(item)
                player.prepare()
                player.play()
                current = song
                played.removeAll { it.url == song.url }
                played.add(0, song)
                val ctx = getApplication<Application>()
                ctx.startService(Intent(ctx, PlaybackService::class.java))
            } catch (e: Exception) {
                error = "Play fail: " + e.javaClass.simpleName + " | " + (e.message ?: "-") + " | " + (e.cause?.javaClass?.simpleName ?: "")
            }
            loading = false
        }
    }

    fun toggle() {
        if (player.isPlaying) player.pause() else player.play()
    }

    fun isLiked(song: Song): Boolean = liked.any { it.url == song.url }

    fun toggleLike(song: Song) {
        if (isLiked(song)) liked.removeAll { it.url == song.url } else liked.add(0, song)
    }
}
