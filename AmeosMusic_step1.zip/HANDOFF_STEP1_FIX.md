# AMEOS MUSIC HANDOFF - STEP 1 FIX (21 Oct 2026, 23:50)
Read with HANDOFF_STEP1.md and HANDOFF_UPDATE_21Oct.md. Do not greet like new. One question per message, short replies, never ask user to edit code, give full zips.

## Where we are
- Step 1 built OK on GitHub Actions, app installs and opens. UI is only a rough version of the Figma. NO SONG PLAYED: error shown was just "Play fail:" (empty message).
- Cause (likely): NewPipeExtractor v0.24.6 is outdated, YouTube broke it (SABR). Latest is v0.26.5. This zip upgrades to v0.26.5 and makes the error text show the exception class + message + cause.
- Zip file is named AmeosMusic_step1.zip (same name) so uploading it OVERWRITES the old one. Workflow build.yml unzips it.

## Next
1. User uploads this zip, waits for green tick, installs (uninstall old first), taps a song.
2. If still "Play fail", ask for the new longer red text and fix. If it plays, go on.
3. Step 2: redo Home + Library to match the 7 Figma screenshots exactly (Home: filter chips, Last Played card with Replay, Recommended Albums grid, Last played albums; Library: Playlists/Liked Artists/Liked Songs grids with View More), then Now Playing, Lyrics (blurred, active line white, "..." menu: Open in Music app / Karaoke / Shuffle), album/artist/playlist pages. Step 3: persistence, queue sheet, About page with AmeOS credit (CC BY 4.0).
