# AMEOS MUSIC HANDOFF - STEP 1 DONE (21 Oct 2026)

For the new Claude: continue seamlessly. Do not greet like a new person. Do not re-ask decided things.
First reply: 2 lines on where we are, then ask the user if Step 1 built OK (paste errors if not).

## User and style
- Android tablet browser only. No PC/terminal/coding. Can tap, copy-paste, upload files to GitHub.
- Short replies, plain words, ONE question per message. Never ask user to edit code. Give full files (zip).
- Claude cannot compile. Builds run on user's GitHub Actions; user pastes errors back.
- User wants the UI copied exactly from the AmeOS 16 Figma screenshots (credit AmeOS team, CC BY 4.0, in About page).
- User wants 3 steps; after EVERY step, produce a handoff file like this one.

## Project
Own native Kotlin + Jetpack Compose music app (package com.ameos.music, label "VAME"), audio via NewPipeExtractor + Media3. Repo uses no gradle wrapper; workflow installs Gradle 8.9. Workflow signs APK with a throwaway key: uninstall old app before installing a new build. APK is in the run's Artifacts (AmeosMusic-apk).

## Plan
- Step 1 (DONE): shell + Home, Search, Your Type, Library screens, floating mini player (prev/play/next), capsule bottom bar, likes (memory only), queue next/prev, auto-next.
- Step 2: Now Playing (big art, heart, slider, time, controls, "This phone", "..." menu: Open in Music app / Karaoke mode / Shuffle), Lyrics view (blurred, active line white), album/artist/playlist pages, real albums/artists from NewPipe.
- Step 3: persistence (likes, playlists Daily/Bangers/Evening, last played via SharedPreferences), queue sheet, About page with AmeOS credit, polish, "Animate cover" optional.

## Files (all under app/src/main/java/com/ameos/music/)
MainActivity.kt (shell), Screens.kt (4 screens), Components.kt (Cover, SongRow, MiniPlayer, BottomBar), MainViewModel.kt (state, queue, likes), MusicRepo.kt (NewPipe search/audioUrl), PlayerHolder.kt, PlaybackService.kt, DownloaderImpl.kt, Theme.kt. Workflow: .github/workflows/android.yml.

## Colours
seed 0xFFC8283D, bg 0xFF130709, pale-pink primary 0xFFFFB3B9, red play button 0xFFE0314A, card 0xFF141010.
