package com.ameos.music

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ArtistItem(val name: String, val cover: String?)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("vame", Context.MODE_PRIVATE)

    fun title(c: Context): String = sp(c).getString("title", "Music") ?: "Music"
    fun setTitle(c: Context, v: String) = sp(c).edit().putString("title", v).apply()

    fun endless(c: Context): Boolean = sp(c).getBoolean("endless", true)
    fun setEndless(c: Context, v: Boolean) = sp(c).edit().putBoolean("endless", v).apply()

    fun officialOnly(c: Context): Boolean = sp(c).getBoolean("officialOnly", true)
    fun setOfficialOnly(c: Context, v: Boolean) = sp(c).edit().putBoolean("officialOnly", v).apply()

    fun stopOnSwipe(c: Context): Boolean = sp(c).getBoolean("stopOnSwipe", true)
    fun setStopOnSwipe(c: Context, v: Boolean) = sp(c).edit().putBoolean("stopOnSwipe", v).apply()

    fun hinglish(c: Context): Boolean = sp(c).getBoolean("hinglish", false)
    fun setHinglish(c: Context, v: Boolean) = sp(c).edit().putBoolean("hinglish", v).apply()

    fun quality(c: Context): Int = sp(c).getInt("quality", 0)
    fun setQuality(c: Context, v: Int) = sp(c).edit().putInt("quality", v).apply()

    fun speed(c: Context): Float = sp(c).getFloat("speed", 1f)
    fun setSpeed(c: Context, v: Float) = sp(c).edit().putFloat("speed", v).apply()

    fun skipSilence(c: Context): Boolean = sp(c).getBoolean("skipSilence", false)
    fun setSkipSilence(c: Context, v: Boolean) = sp(c).edit().putBoolean("skipSilence", v).apply()

    fun finishSong(c: Context): Boolean = sp(c).getBoolean("finishSong", true)
    fun setFinishSong(c: Context, v: Boolean) = sp(c).edit().putBoolean("finishSong", v).apply()

    fun onboarded(c: Context): Boolean = sp(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context, v: Boolean) = sp(c).edit().putBoolean("onboarded", v).apply()

    fun genres(c: Context): Set<String> =
        (sp(c).getString("genres", "") ?: "").split("|").filter { it.isNotBlank() }.toSet()

    fun setGenres(c: Context, v: Set<String>) =
        sp(c).edit().putString("genres", v.joinToString("|")).apply()

    fun likes(c: Context): List<Song> {
        val raw = sp(c).getString("likes", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Song(
                    title = o.optString("t"),
                    artist = o.optString("a"),
                    url = o.optString("u"),
                    cover = if (o.isNull("c")) null else o.optString("c"),
                    durationSec = o.optLong("d")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveLikes(c: Context, list: List<Song>) {
        val arr = JSONArray()
        for (s in list) {
            val o = JSONObject()
            o.put("t", s.title)
            o.put("a", s.artist)
            o.put("u", s.url)
            o.put("c", s.cover ?: JSONObject.NULL)
            o.put("d", s.durationSec)
            arr.put(o)
        }
        sp(c).edit().putString("likes", arr.toString()).apply()
    }

    // played history (Home > Last played), saved so it survives closing the app
    fun history(c: Context): List<Song> {
        val raw = sp(c).getString("history", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Song(
                    title = o.optString("t"),
                    artist = o.optString("a"),
                    url = o.optString("u"),
                    cover = if (o.isNull("c")) null else o.optString("c"),
                    durationSec = o.optLong("d")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveHistory(c: Context, list: List<Song>) {
        val arr = JSONArray()
        for (s in list) {
            val o = JSONObject()
            o.put("t", s.title)
            o.put("a", s.artist)
            o.put("u", s.url)
            o.put("c", s.cover ?: JSONObject.NULL)
            o.put("d", s.durationSec)
            arr.put(o)
        }
        sp(c).edit().putString("history", arr.toString()).apply()
    }

    // liked artists (only when you tap the heart on an artist page)
    fun likedArtists(c: Context): List<ArtistItem> {
        val raw = sp(c).getString("likedArtists", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ArtistItem(
                    name = o.optString("n"),
                    cover = if (o.isNull("c")) null else o.optString("c")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveLikedArtists(c: Context, list: List<ArtistItem>) {
        val arr = JSONArray()
        for (a in list) {
            val o = JSONObject()
            o.put("n", a.name)
            o.put("c", a.cover ?: JSONObject.NULL)
            arr.put(o)
        }
        sp(c).edit().putString("likedArtists", arr.toString()).apply()
    }
}
