package com.ameos.music

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("vame", Context.MODE_PRIVATE)

    fun title(c: Context): String = sp(c).getString("title", "Music") ?: "Music"
    fun setTitle(c: Context, v: String) = sp(c).edit().putString("title", v).apply()

    fun endless(c: Context): Boolean = sp(c).getBoolean("endless", true)
    fun setEndless(c: Context, v: Boolean) = sp(c).edit().putBoolean("endless", v).apply()

    fun finishSong(c: Context): Boolean = sp(c).getBoolean("finishSong", true)
    fun setFinishSong(c: Context, v: Boolean) = sp(c).edit().putBoolean("finishSong", v).apply()

    fun onboarded(c: Context): Boolean = sp(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context, v: Boolean) = sp(c).edit().putBoolean("onboarded", v).apply()

    fun genres(c: Context): Set<String> =
        (sp(c).getString("genres", "") ?: "").split("|").filter { it.isNotBlank() }.toSet()

    fun setGenres(c: Context, v: Set<String>) =
        sp(c).edit().putString("genres", v.joinToString("|")).apply()

    fun likes(c: Context): List<Song> {
        val raw = sp(c).getString("likes", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Song(
                    title = o.optString("t"),
                    artist = o.optString("a"),
                    url = o.optString("u"),
                    cover = if (o.isNull("c")) null else o.optString("c"),
                    durationSec = o.optLong("d")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveLikes(c: Context, list: List<Song>) {
        val arr = JSONArray()
        for (s in list) {
            val o = JSONObject()
            o.put("t", s.title)
            o.put("a", s.artist)
            o.put("u", s.url)
            o.put("c", s.cover ?: JSONObject.NULL)
            o.put("d", s.durationSec)
            arr.put(o)
        }
        sp(c).edit().putString("likes", arr.toString()).apply()
    }

    // played history (Home > Last played), saved so it survives closing the app
    fun history(c: Context): List<Song> {
        val raw = sp(c).getString("history", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Song(
                    title = o.optString("t"),
                    artist = o.optString("a"),
                    url = o.optString("u"),
                    cover = if (o.isNull("c")) null else o.optString("c"),
                    durationSec = o.optLong("d")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveHistory(c: Context, list: List<Song>) {
        val arr = JSONArray()
        for (s in list) {
            val o = JSONObject()
            o.put("t", s.title)
            o.put("a", s.artist)
            o.put("u", s.url)
            o.put("c", s.cover ?: JSONObject.NULL)
            o.put("d", s.durationSec)
            arr.put(o)
        }
        sp(c).edit().putString("history", arr.toString()).apply()
    }
}
