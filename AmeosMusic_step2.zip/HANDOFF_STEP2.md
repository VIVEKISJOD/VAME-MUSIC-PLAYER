# AMEOS MUSIC HANDOFF - STEP 2 (22 Oct 2026)
Read with HANDOFF_STEP1.md + HANDOFF_UPDATE_21Oct.md. Do not greet like new. ONE question per message, short replies, never ask user to edit code, give full zips, make a handoff with every file.

## Done
- Step 1 + NewPipeExtractor v0.26.5: songs PLAY now. User said it felt slow and the mini-player pill did not open the Figma Now Playing page.
- Step 2 zip (AmeosMusic_step2.zip, versionName 0.2) adds: Now Playing screen (NowPlaying.kt: big cover, heart, slider, times, prev/play/next, "This phone", "..." menu with Open in Music app / Karaoke mode / Shuffle), Lyrics view (Lyrics.kt, lyrics from LRCLIB, synced, active line white, tap line to seek, tap small cover to go back), pill opens Now Playing, back button closes it. Speed: song shows instantly in mini player, audio link of the next song is prefetched and cached.
- NOT compiled by Claude (no network). User builds on GitHub Actions and pastes errors.

## Repo / build (unchanged)
github.com/VIVEKISJOD/VAME-MUSIC-PLAYER, workflow build.yml unzips the HIGHEST AmeosMusic_step*.zip in repo root. User uploads zips on tablet. Old zips can stay. Uninstall old app before installing new APK.

## Next
1. User builds step2, tests: tap pill -> Now Playing; tap cover -> lyrics; "..." menu; speed.
2. If build errors: user pastes them, fix, send AmeosMusic_step3.zip (always bump number, never reuse a name).
3. Step 3: redo Home + Library to match Figma exactly (Home: chips All/Music/Podcasts/Playlists, Last Played card with Replay, Recommended Albums 2x2 list, Last played albums row; Library: Playlists/Liked Artists/Liked Songs grids + View More), Search "Recommended" 2x2 genre tiles, Your Type "Discover new Music", album/artist/playlist pages (Daily etc). 
4. Step 4: persistence (likes, playlists, last played via SharedPreferences), queue sheet, "Animate cover", About page with AmeOS credit (CC BY 4.0), polish.
