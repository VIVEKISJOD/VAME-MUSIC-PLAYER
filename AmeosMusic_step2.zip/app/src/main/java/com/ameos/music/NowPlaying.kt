package com.ameos.music

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs

private val Pink = Color(0xFFFFB3B9)

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return (s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0')
}

@Composable
fun NowPlayingScreen(vm: MainViewModel) {
    val song = vm.current ?: return
    val ctx = LocalContext.current
    var lyricsMode by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    BackHandler { vm.showPlayer = false }

    LaunchedEffect(song.url) {
        while (true) {
            pos = vm.player.currentPosition
            val d = vm.player.duration
            dur = if (d > 0) d else song.durationSec * 1000
            delay(300)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF7A1F22), Color(0xFF4A1014), Color(0xFF2A0A0D))
                )
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { }
    ) {
        Cover(
            song.cover,
            Modifier.fillMaxSize().alpha(0.30f).blur(50.dp),
            RoundedCornerShape(0.dp)
        )
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            // header
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (lyricsMode) {
                    Cover(
                        song.cover,
                        Modifier.size(44.dp).clickable { lyricsMode = false },
                        RoundedCornerShape(8.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                } else {
                    IconButton(onClick = { vm.showPlayer = false }) {
                        Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White)
                    }
                }
                Column(
                    Modifier.weight(1f),
                    horizontalAlignment =
                        if (lyricsMode) Alignment.Start else Alignment.CenterHorizontally
                ) {
                    Text(
                        song.artist, fontSize = 12.sp, color = Color(0xFFE6BDC0),
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        song.title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                        color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                if (!lyricsMode) Spacer(Modifier.width(48.dp))
            }

            // body: cover or lyrics
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (lyricsMode) {
                    LyricsView(vm, pos)
                } else {
                    Cover(
                        song.cover,
                        Modifier
                            .align(Alignment.Center)
                            .padding(vertical = 20.dp)
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clickable { lyricsMode = true },
                        RoundedCornerShape(24.dp)
                    )
                }
            }

            // heart + queue
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIcon(
                    if (vm.isLiked(song)) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder
                ) { vm.toggleLike(song) }
                Spacer(Modifier.weight(1f))
                RoundIcon(Icons.Filled.QueueMusic) { }
            }

            // progress
            val max = dur.coerceAtLeast(1L).toFloat()
            val shown = if (dragging) dragValue else pos.toFloat()
            Slider(
                value = shown.coerceIn(0f, max),
                onValueChange = { dragging = true; dragValue = it },
                onValueChangeFinished = {
                    vm.player.seekTo(dragValue.toLong())
                    pos = dragValue.toLong()
                    dragging = false
                },
                valueRange = 0f..max,
                colors = SliderDefaults.colors(
                    thumbColor = Pink,
                    activeTrackColor = Pink,
                    inactiveTrackColor = Color(0x55FFFFFF)
                )
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
                Text(fmt(shown.toLong()), fontSize = 12.sp, color = Color(0xFFE6BDC0))
                Spacer(Modifier.weight(1f))
                Text(fmt(dur), fontSize = 12.sp, color = Color(0xFFE6BDC0))
            }

            // controls
            Row(
                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.prev() }, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Filled.SkipPrevious, null, tint = Pink, modifier = Modifier.size(36.dp))
                }
                Spacer(Modifier.width(16.dp))
                Box(
                    Modifier.size(72.dp).clip(CircleShape).clickable { vm.toggle() },
                    contentAlignment = Alignment.Center
                ) {
                    if (vm.loading) {
                        CircularProgressIndicator(
                            Modifier.size(34.dp), color = Pink, strokeWidth = 3.dp
                        )
                    } else {
                        Icon(
                            if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            null, tint = Pink, modifier = Modifier.size(48.dp)
                        )
                    }
                }
                Spacer(Modifier.width(16.dp))
                IconButton(onClick = { vm.next() }, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Filled.SkipNext, null, tint = Pink, modifier = Modifier.size(36.dp))
                }
            }

            // bottom row
            Row(
                Modifier.fillMaxWidth().padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0x33FFFFFF))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.PhoneAndroid, null, tint = Pink, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("This phone", fontSize = 12.sp, color = Pink)
                }
                Spacer(Modifier.weight(1f))
                Box {
                    RoundIcon(Icons.Filled.MoreHoriz) { menuOpen = true }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Open in Music app") },
                            leadingIcon = { Icon(Icons.Filled.MusicNote, null) },
                            onClick = {
                                menuOpen = false
                                try {
                                    ctx.startActivity(
                                        Intent(Intent.ACTION_VIEW, Uri.parse(song.url))
                                    )
                                } catch (e: Exception) {
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Karaoke mode") },
                            leadingIcon = { Icon(Icons.Filled.Mic, null) },
                            onClick = { menuOpen = false; lyricsMode = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Shuffle") },
                            leadingIcon = { Icon(Icons.Filled.Shuffle, null) },
                            onClick = { menuOpen = false; vm.shuffleQueue() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LyricsView(vm: MainViewModel, pos: Long) {
    val lines = vm.lyrics
    if (vm.lyricsLoading || lines.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                if (vm.lyricsLoading) "Loading lyrics..." else "No lyrics found for this song",
                color = Color(0xFFE6BDC0), fontSize = 16.sp, textAlign = TextAlign.Center
            )
        }
        return
    }
    val synced = vm.lyricsSynced
    val active = if (synced) lines.indexOfLast { it.timeMs <= pos } else -1
    val state = rememberLazyListState()
    LaunchedEffect(active) {
        if (active >= 0) state.animateScrollToItem(active, -250)
    }
    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 120.dp)
    ) {
        itemsIndexed(lines) { i, line ->
            val a = when {
                !synced -> 0.85f
                active < 0 -> 0.5f
                else -> when (abs(i - active)) {
                    0 -> 1f
                    1 -> 0.6f
                    2 -> 0.4f
                    else -> 0.25f
                }
            }
            Text(
                if (line.text.isBlank()) "..." else line.text,
                fontSize = 26.sp,
                lineHeight = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = a),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = synced) { vm.player.seekTo(line.timeMs) }
                    .padding(vertical = 8.dp)
            )
        }
    }
}
